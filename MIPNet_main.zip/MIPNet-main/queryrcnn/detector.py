import torch
from torch import nn
import torch.nn.functional as F
from detectron2.modeling import META_ARCH_REGISTRY, build_backbone, detector_postprocess
from detectron2.structures import Boxes, ImageList, Instances
from .loss import SetCriterion, HungarianMatcher
from .head import DynamicHead
from .util.box_ops import box_xyxy_to_cxcywh
from .dense_heads import build_rpn_head
from .Illumination_Invariant import build_net
from .Clip_loss import SemanticLoss



__all__ = ["SparseRCNN"]


@META_ARCH_REGISTRY.register()
class QueryRCNN(nn.Module):
    def __init__(self, cfg, enhance_semantic_loss_weight=0.1):
        super().__init__()

        self.device = torch.device(cfg.MODEL.DEVICE)
        self.enhance_semantic_loss_weight = enhance_semantic_loss_weight

        self.in_features = cfg.MODEL.ROI_HEADS.IN_FEATURES
        self.rpn_infeats = cfg.MODEL.RPN.IN_FEATURES
        self.num_classes = cfg.MODEL.SparseRCNN.NUM_CLASSES
        self.num_proposals = cfg.MODEL.SparseRCNN.NUM_PROPOSALS
        self.hidden_dim = cfg.MODEL.SparseRCNN.HIDDEN_DIM

        self.num_heads = cfg.MODEL.SparseRCNN.NUM_HEADS
        self.with_pos = cfg.MODEL.QueryRCNN.WITH_POS


        def weights_init(m):
            classname = m.__class__.__name__
            if classname.find('Conv3d') != -1 or classname.find('Conv2d') != -1 or classname.find('ConvTranspose2d') != -1 or classname.find('ConvTranspose3d') != -1:
                m.weight.data.normal_(0.0, 0.02)
                #m.bias.data.fill_(0)
            elif classname.find('BatchNorm') != -1:
                m.weight.data.normal_(1.0, 0.02)
                m.bias.data.fill_(0)


        # build the feat-enhancer module
        self.feat_enhancer = build_net(3)
        self.feat_enhancer.apply(weights_init)

        enhance_prompts = [
            "a well-lit and sharp image.",
        ]

        negative_prompts = [
            "a dark and noisy image.",
        ]
        self.enhance_semantic_loss_fn = SemanticLoss(enhance_prompts, negative_prompts).to(self.device)


        # Build Backbone.
        self.backbone = build_backbone(cfg)
        self.size_divisibility = self.backbone.size_divisibility
        
        self.rpn_head = build_rpn_head(cfg, input_shape=self.backbone.output_shape(), in_features=cfg.MODEL.RPN.IN_FEATURES)  
             

        # Build Dynamic Head.
        self.head = DynamicHead(cfg=cfg, roi_input_shape=self.backbone.output_shape())

        # Loss parameters:
        class_weight = cfg.MODEL.SparseRCNN.CLASS_WEIGHT
        giou_weight = cfg.MODEL.SparseRCNN.GIOU_WEIGHT
        l1_weight = cfg.MODEL.SparseRCNN.L1_WEIGHT
        no_object_weight = cfg.MODEL.SparseRCNN.NO_OBJECT_WEIGHT
        self.deep_supervision = cfg.MODEL.SparseRCNN.DEEP_SUPERVISION
        self.use_focal = cfg.MODEL.SparseRCNN.USE_FOCAL

        # Build Criterion.
        matcher = HungarianMatcher(cfg=cfg,
                                   cost_class=class_weight, 
                                   cost_bbox=l1_weight, 
                                   cost_giou=giou_weight,
                                   use_focal=self.use_focal)
        
        weight_dict = {"loss_ce": class_weight, "loss_bbox": l1_weight, "loss_giou": giou_weight}

        if self.deep_supervision:
            aux_weight_dict = {}
            for i in range(self.num_heads - 1):
                aux_weight_dict.update({k + f"_{i}": v for k, v in weight_dict.items()})
            weight_dict.update(aux_weight_dict)


        losses = ["labels", "boxes"]


        self.criterion = SetCriterion(cfg=cfg,
                                      num_classes=self.num_classes,
                                      matcher=matcher,
                                      weight_dict=weight_dict,
                                      eos_coef=no_object_weight,
                                      losses=losses,
                                      use_focal=self.use_focal)

        pixel_mean = torch.Tensor(cfg.MODEL.PIXEL_MEAN).to(self.device).view(3, 1, 1)
        pixel_std = torch.Tensor(cfg.MODEL.PIXEL_STD).to(self.device).view(3, 1, 1)
        self.normalizer = lambda x: (x - pixel_mean) / pixel_std
        self.to(self.device)


        self.depth_conv = nn.Conv2d(1, 256, kernel_size=1)
        self.phase_conv = nn.Conv2d(24, 256, kernel_size=1)
        self.fusion_conv = nn.Conv2d(256 * 3, 256, kernel_size=1)
    #
    def fuse_features(self, features, depth_map, phase_features):

        new_features = []
        for f in features:
            if f.dim() == 3:
                f = f.unsqueeze(0)
            new_features.append(f)

        features = torch.cat(new_features, dim=0)

        depth_resized = F.adaptive_avg_pool2d(depth_map, features.shape[-2:])  # (B, 1, H, W)
        phase_resized = F.adaptive_avg_pool2d(phase_features, features.shape[-2:])  # (B, 8, H, W)

        if depth_resized.shape[0] != features.shape[0]:
            depth_resized = depth_resized[:features.shape[0]]
        if phase_resized.shape[0] != features.shape[0]:
            phase_resized = phase_resized[:features.shape[0]]

        depth_adjusted = self.depth_conv(depth_resized)  # (B, 256, H, W)
        phase_adjusted = self.phase_conv(phase_resized)  # (B, 256, H, W)

        fusion_weight = torch.sigmoid(
            self.fusion_conv(torch.cat([features, depth_adjusted, phase_adjusted], dim=1)))  # (B, 256, H, W)
        fused_features = features + fusion_weight * (depth_adjusted + phase_adjusted)

        return fused_features

    def simple_test(self, batched_inputs):
        images, images_whwh = self.preprocess_image(batched_inputs)

        enhanced_image, depth_map, phase_features = self.feat_enhancer(images.tensor)

        src = self.backbone(enhanced_image)
        features = list()

        pos_rcnn = list()
        for f in self.in_features:
            feature = src[f]
            feature = self.fuse_features(feature, depth_map, phase_features)
            features.append(feature)


        enhanced_image_list = enhanced_image.tolist()
        outL = []
        for x in enhanced_image_list:
            outL.append(torch.Tensor(x))


        imgs = ImageList.from_tensors(outL, self.size_divisibility)

        proposals, _ = self.rpn_head(imgs, src, None)
        proposal_boxes = torch.stack([x.proposal_boxes.tensor for x in proposals])
        init_boxes = proposal_boxes.detach()
        proposal_features = torch.stack([x.proposal_feats for x in proposals])

        outputs_class, outputs_coord = self.head(features, init_boxes, proposal_features, pos_rcnn)

        results = self.inference(outputs_class[-1], outputs_coord[-1], images.image_sizes)
        processed_results = []

        for results_per_image, input_per_image, image_size in zip(results, batched_inputs, images.image_sizes):
            height = input_per_image.get("height", image_size[0])
            width = input_per_image.get("width", image_size[1])
            r = detector_postprocess(results_per_image, height, width)
            processed_results.append({"instances": r})
        return processed_results

    
    def forward(self, batched_inputs):
        """
        Args:
            batched_inputs: a list, batched outputs of :class:`DatasetMapper` .
                Each item in the list contains the inputs for one image.
                For now, each item in the list is a dict that contains:

                * image: Tensor, image in (C, H, W) format.
                * instances: Instances

                Other information that's included in the original dicts, such as:

                * "height", "width" (int): the output resolution of the model, used in inference.
                  See :meth:`postprocess` for details.
        """
        if not self.training:
            return self.simple_test(batched_inputs)

        images, images_whwh = self.preprocess_image(batched_inputs)

        enhanced_image, depth_map, phase_features = self.feat_enhancer(images.tensor)

        src = self.backbone(enhanced_image)

        features = list()
        
        pos_rcnn = list()

        for f in self.in_features:
            feature = src[f]
            feature = self.fuse_features(feature, depth_map, phase_features)
            features.append(feature)


        gt_instances = [x["instances"].to(self.device) for x in batched_inputs]
        targets = self.prepare_targets(gt_instances)

        imgs = ImageList.from_tensors(enhanced_image.unbind(dim=0), self.size_divisibility)
        proposals, losses = self.rpn_head(imgs, src, targets)

        proposal_boxes = torch.stack([x.proposal_boxes.tensor for x in proposals])
        init_boxes = proposal_boxes.detach()
        proposal_features = torch.stack([x.proposal_feats for x in proposals])

        # Prediction.
        outputs_class, outputs_coord = self.head(features, init_boxes, proposal_features, pos_rcnn)
        
        output = {'pred_logits': outputs_class[-1], 'pred_boxes': outputs_coord[-1]}

        if self.deep_supervision:
            output['aux_outputs'] = [{'pred_logits': a, 'pred_boxes': b}
                                        for a, b in zip(outputs_class[:-1], outputs_coord[:-1])]
        
        loss_dict = self.criterion(output, targets, enhanced_image)
        weight_dict = self.criterion.weight_dict
        for k in loss_dict.keys():
            if k in weight_dict:
                loss_dict[k] *= weight_dict[k]
        loss_dict.update(losses)


        enhance_semantic_loss = self.enhance_semantic_loss_fn(enhanced_image)
        loss_dict['enhance_semantic_loss'] = self.enhance_semantic_loss_weight * enhance_semantic_loss

        return loss_dict


    def prepare_targets(self, targets):
        new_targets = []
        for targets_per_image in targets:
            target = {}
            h, w = targets_per_image.image_size
            image_size_xyxy = torch.as_tensor([w, h, w, h], dtype=torch.float, device=self.device)
            gt_classes = targets_per_image.gt_classes
            gt_boxes = targets_per_image.gt_boxes.tensor
            gt_boxes = box_xyxy_to_cxcywh(gt_boxes)
            target["labels"] = gt_classes.to(self.device)
            target["boxes"] = gt_boxes.to(self.device)
            target["boxes_xyxy"] = targets_per_image.gt_boxes.tensor.to(self.device)
            target["image_size_xyxy"] = image_size_xyxy.to(self.device)
            image_size_xyxy_tgt = image_size_xyxy.unsqueeze(0).repeat(len(gt_boxes), 1)
            target["image_size_xyxy_tgt"] = image_size_xyxy_tgt.to(self.device)
            target["area"] = targets_per_image.gt_boxes.area().to(self.device)
            new_targets.append(target)

        return new_targets

    def inference(self, box_cls, box_pred, image_sizes):
        """
        Arguments:
            box_cls (Tensor): tensor of shape (batch_size, num_proposals, K).
                The tensor predicts the classification probability for each proposal.
            box_pred (Tensor): tensors of shape (batch_size, num_proposals, 4).
                The tensor predicts 4-vector (x,y,w,h) box
                regression values for every proposal
            image_sizes (List[torch.Size]): the input image sizes

        Returns:
            results (List[Instances]): a list of #images elements.
        """
        assert len(box_cls) == len(image_sizes)
        results = []

        if self.use_focal:
            scores = torch.sigmoid(box_cls)
            labels = torch.arange(self.num_classes, device=self.device).\
                     unsqueeze(0).repeat(self.num_proposals, 1).flatten(0, 1)

            for i, (scores_per_image, box_pred_per_image, image_size) in enumerate(zip(
                    scores, box_pred, image_sizes
            )):
                # scores_per_image = scores_per_image[..., 0:1]
                result = Instances(image_size)
                scores_per_image, topk_indices = scores_per_image.flatten(0, 1).topk(self.num_proposals, sorted=False)
                labels_per_image = labels[topk_indices]
                box_pred_per_image = box_pred_per_image.view(-1, 1, 4).repeat(1, self.num_classes, 1).view(-1, 4)
                box_pred_per_image = box_pred_per_image[topk_indices]

                result.pred_boxes = Boxes(box_pred_per_image)
                result.scores = scores_per_image
                result.pred_classes = labels_per_image
                results.append(result)
        else:
            # For each box we assign the best class or the second best if the best on is `no_object`.
            scores, labels = F.softmax(box_cls, dim=-1)[:, :, :-1].max(-1)

            for i, (scores_per_image, labels_per_image, box_pred_per_image, image_size) in enumerate(zip(
                scores, labels, box_pred, image_sizes
            )):
                result = Instances(image_size)
                result.pred_boxes = Boxes(box_pred_per_image)
                result.pred_boxes.scale(scale_x=image_size[1], scale_y=image_size[0])

                result.scores = scores_per_image
                result.pred_classes = labels_per_image
                results.append(result)
        return results

    def preprocess_image(self, batched_inputs):
        """
        Normalize, pad and batch the input images.
        """
        images = [self.normalizer(x["image"].to(self.device)) for x in batched_inputs]
        #images = [x["image"].float().to(self.device) for x in batched_inputs]
        images = ImageList.from_tensors(images, self.size_divisibility)


        images_whwh = list()
        for bi in batched_inputs:
            h, w = bi["image"].shape[-2:]
            images_whwh.append(torch.tensor([w, h, w, h], dtype=torch.float32, device=self.device))
        images_whwh = torch.stack(images_whwh)

        return images, images_whwh
